from flask import Flask, request, jsonify, session
from flask_socketio import SocketIO, emit, join_room, leave_room
from flask_cors import CORS
from database import Database
from whatsapp_service import WhatsAppService, WhatsAppSimulator
import asyncio
from functools import wraps
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'sua-chave-secreta-aqui-mude-em-producao'
CORS(app, supports_credentials=True)

# Inicializar Socket.io
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

# Inicializar Database
db = Database()

# Inicializar WhatsApp Service
whatsapp = WhatsAppService(db, socketio)

# Simulador (remover em produção)
simulator = WhatsAppSimulator(whatsapp)

# ===== DECORATORS =====

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Não autenticado'}), 401
        return f(*args, **kwargs)
    return decorated_function

def role_required(*roles):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'user_id' not in session:
                return jsonify({'error': 'Não autenticado'}), 401
            if session.get('role') not in roles:
                return jsonify({'error': 'Sem permissão'}), 403
            return f(*args, **kwargs)
        return decorated_function
    return decorator

# ===== ROTAS DE AUTENTICAÇÃO =====

@app.route('/api/login', methods=['POST'])
def login():
    data = request.json
    username = data.get('username')
    password = data.get('password')
    
    user = db.authenticate_user(username, password)
    
    if user:
        session['user_id'] = user['id']
        session['username'] = user['username']
        session['name'] = user['name']
        session['role'] = user['role']
        
        return jsonify({
            'success': True,
            'user': {
                'id': user['id'],
                'username': user['username'],
                'name': user['name'],
                'role': user['role']
            }
        })
    
    return jsonify({'error': 'Credenciais inválidas'}), 401

@app.route('/api/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'success': True})

@app.route('/api/me', methods=['GET'])
@login_required
def get_current_user():
    return jsonify({
        'id': session['user_id'],
        'username': session['username'],
        'name': session['name'],
        'role': session['role']
    })

# ===== ROTAS DE USUÁRIOS =====

@app.route('/api/users', methods=['GET'])
@role_required('admin', 'gestor')
def get_users():
    users = db.get_all_users()
    return jsonify(users)

@app.route('/api/users', methods=['POST'])
@role_required('admin')
def create_user():
    data = request.json
    user_id = db.create_user(
        username=data['username'],
        password=data['password'],
        name=data['name'],
        role=data['role']
    )
    
    if user_id:
        db.log_action(session['user_id'], 'create', 'user', user_id, f"Criou usuário {data['username']}")
        return jsonify({'success': True, 'user_id': user_id})
    return jsonify({'error': 'Usuário já existe'}), 400

@app.route('/api/users/<int:user_id>', methods=['PUT'])
@role_required('admin')
def update_user(user_id):
    data = request.json
    db.update_user(user_id, data['name'], data['role'], data.get('active', 1))
    db.log_action(session['user_id'], 'update', 'user', user_id, f"Atualizou usuário")
    return jsonify({'success': True})

@app.route('/api/users/<int:user_id>/password', methods={'PUT'])
@login_required
def change_password(user_id):
    # Admin pode trocar senha de qualquer um, usuário só a própria
    if session['role'] != 'admin' and session['user_id'] != user_id:
        return jsonify({'error': 'Sem permissão'}), 403
    
    data = request.json
    db.change_password(user_id, data['new_password'])
    db.log_action(session['user_id'], 'change_password', 'user', user_id)
    return jsonify({'success': True})

@app.route('/api/users/<int:user_id>', methods=['DELETE'])
@role_required('admin')
def delete_user(user_id):
    if user_id == session['user_id']:
        return jsonify({'error': 'Não pode desativar a si mesmo'}), 400
    
    db.delete_user(user_id)
    db.log_action(session['user_id'], 'delete', 'user', user_id)
    return jsonify({'success': True})

# ===== AUDIT LOG =====

@app.route('/api/audit-log', methods=['GET'])
@role_required('admin', 'gestor')
def get_audit_log():
    entity_type = request.args.get('entity_type')
    entity_id = request.args.get('entity_id')
    limit = int(request.args.get('limit', 100))
    
    logs = db.get_audit_log(limit, entity_type, int(entity_id) if entity_id else None)
    return jsonify(logs)

# ===== ROTAS DE LEADS =====

@app.route('/api/leads', methods=['GET'])
@login_required
def get_leads():
    role = session['role']
    user_id = session['user_id']
    
    if role in ['admin', 'gestor']:
        # Admin e Gestor veem todos os leads
        leads = db.get_all_leads()
    else:
        # Vendedor vê apenas seus leads
        leads = db.get_leads_by_vendedor(user_id)
    
    return jsonify(leads)

@app.route('/api/leads/queue', methods=['GET'])
@login_required
def get_leads_queue():
    """Retorna leads não atribuídos (fila)"""
    leads = db.get_leads_by_status('novo')
    return jsonify(leads)

@app.route('/api/leads/<int:lead_id>/assign', methods=['POST'])
@login_required
def assign_lead(lead_id):
    """Vendedor pega um lead da fila"""
    user_id = session['user_id']
    db.assign_lead(lead_id, user_id)
    db.log_action(user_id, 'assign', 'lead', lead_id, f"Pegou lead da fila")
    
    # Notificar via Socket.io
    socketio.emit('lead_assigned', {
        'lead_id': lead_id,
        'vendedor_id': user_id,
        'vendedor_name': session['name']
    })
    
    return jsonify({'success': True})

@app.route('/api/leads/<int:lead_id>/status', methods=['PUT'])
@login_required
def update_lead_status(lead_id):
    """Atualiza status do lead"""
    data = request.json
    status = data.get('status')
    
    db.update_lead_status(lead_id, status)
    
    # Notificar via Socket.io
    socketio.emit('lead_updated', {
        'lead_id': lead_id,
        'status': status
    })
    
    return jsonify({'success': True})

@app.route('/api/leads/<int:lead_id>/transfer', methods=['POST'])
@role_required('admin', 'gestor')
def transfer_lead(lead_id):
    """Transfere lead para outro vendedor"""
    data = request.json
    new_vendedor_id = data.get('vendedor_id')
    
    db.assign_lead(lead_id, new_vendedor_id)
    
    socketio.emit('lead_transferred', {
        'lead_id': lead_id,
        'new_vendedor_id': new_vendedor_id
    })
    
    return jsonify({'success': True})

# ===== ROTAS DE MENSAGENS =====

@app.route('/api/leads/<int:lead_id>/messages', methods=['GET'])
@login_required
def get_messages(lead_id):
    """Retorna histórico de mensagens do lead"""
    messages = db.get_messages_by_lead(lead_id)
    return jsonify(messages)

@app.route('/api/leads/<int:lead_id>/messages', methods=['POST'])
@login_required
def send_message_route(lead_id):
    """Envia mensagem para o lead"""
    data = request.json
    content = data.get('content')
    user_id = session['user_id']
    
    # Buscar lead para pegar o telefone
    leads = db.get_all_leads()
    lead = next((l for l in leads if l['id'] == lead_id), None)
    
    if not lead:
        return jsonify({'error': 'Lead não encontrado'}), 404
    
    # Enviar via WhatsApp (agora síncrono com VenomBot)
    success = whatsapp.send_message(lead['phone'], content, user_id)
    
    if success:
        return jsonify({'success': True})
    else:
        return jsonify({'error': 'Falha ao enviar mensagem'}), 500

# ===== WEBHOOK PARA RECEBER MENSAGENS DO VENOMBOT =====

@app.route('/api/webhook/message', methods=['POST'])
def webhook_message():
    """
    Webhook para receber mensagens do VenomBot
    Chamado pelo venom_integration.js quando chega nova mensagem
    """
    data = request.json
    
    print(f"🔔 Webhook recebido: {data}")
    
    # Processar mensagem
    asyncio.run(whatsapp.on_message({
        'from': f"{data['phone']}@c.us",
        'body': data['content'],
        'notifyName': data['name'],
        'fromMe': False
    }))
    
    return jsonify({'success': True})

# ===== ROTAS DE NOTAS INTERNAS =====

@app.route('/api/leads/<int:lead_id>/notes', methods=['GET'])
@login_required
def get_notes(lead_id):
    """Retorna notas internas do lead"""
    notes = db.get_internal_notes(lead_id)
    return jsonify(notes)

@app.route('/api/leads/<int:lead_id>/notes', methods=['POST'])
@login_required
def add_note(lead_id):
    """Adiciona nota interna ao lead"""
    data = request.json
    note = data.get('note')
    user_id = session['user_id']
    
    db.add_internal_note(lead_id, user_id, note)
    
    # Notificar gestores
    socketio.emit('new_note', {
        'lead_id': lead_id,
        'note': note,
        'user_name': session['name']
    }, room='gestores')
    
    return jsonify({'success': True})

# ===== ROTAS DE WHATSAPP =====

@app.route('/api/whatsapp/status', methods=['GET'])
@login_required
def whatsapp_status():
    """Retorna status da conexão WhatsApp"""
    return jsonify(whatsapp.get_status())

# ===== ROTA DE TESTE (Simulador) =====

@app.route('/api/simulate/message', methods=['POST'])
def simulate_message():
    """Simula mensagem recebida (apenas para testes)"""
    data = request.json
    asyncio.run(simulator.simulate_incoming_message(
        phone=data.get('phone'),
        content=data.get('content'),
        name=data.get('name', 'Lead Teste')
    ))
    return jsonify({'success': True})

# ===== EVENTOS SOCKET.IO =====

@socketio.on('connect')
def handle_connect():
    print(f'🔌 Cliente conectado')

@socketio.on('disconnect')
def handle_disconnect():
    print(f'🔌 Cliente desconectado')

@socketio.on('join_room')
def handle_join_room(data):
    """Cliente entra em uma sala (ex: sala de gestores)"""
    room = data.get('room')
    join_room(room)
    print(f'📍 Cliente entrou na sala: {room}')

@socketio.on('leave_room')
def handle_leave_room(data):
    """Cliente sai de uma sala"""
    room = data.get('room')
    leave_room(room)
    print(f'📍 Cliente saiu da sala: {room}')

# ===== INICIALIZAÇÃO =====

if __name__ == '__main__':
    print("🚀 Iniciando CRM WhatsApp...")
    print("📊 Banco de dados inicializado")
    print("👤 Usuário padrão: admin / admin123")
    print("")
    print("🌐 API rodando em: http://localhost:5000")
    print("🔌 Socket.io pronto para conexões")
    print("")
    
    # Inicializar WhatsApp (comentado para MVP sem VenomBot real)
    # asyncio.run(whatsapp.initialize())
    
    socketio.run(app, debug=True, host='0.0.0.0', port=5000)
