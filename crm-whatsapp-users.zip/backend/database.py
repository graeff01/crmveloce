import sqlite3
from datetime import datetime
import hashlib

class Database:
    def __init__(self, db_path='crm_whatsapp.db'):
        self.db_path = db_path
        self.init_database()
    
    def get_connection(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn
    
    def init_database(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Tabela de usuários
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                name TEXT NOT NULL,
                role TEXT NOT NULL CHECK(role IN ('admin', 'gestor', 'vendedor')),
                active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Tabela de leads
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS leads (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                phone TEXT UNIQUE NOT NULL,
                name TEXT,
                status TEXT DEFAULT 'novo' CHECK(status IN ('novo', 'em_atendimento', 'qualificado', 'perdido', 'ganho')),
                assigned_to INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (assigned_to) REFERENCES users(id)
            )
        ''')
        
        # Tabela de mensagens
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                lead_id INTEGER NOT NULL,
                sender_type TEXT NOT NULL CHECK(sender_type IN ('lead', 'vendedor')),
                sender_id INTEGER,
                content TEXT NOT NULL,
                message_type TEXT DEFAULT 'text',
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                read_by_lead BOOLEAN DEFAULT 0,
                FOREIGN KEY (lead_id) REFERENCES leads(id),
                FOREIGN KEY (sender_id) REFERENCES users(id)
            )
        ''')
        
        # Tabela de notas internas
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS internal_notes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                lead_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                note TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (lead_id) REFERENCES leads(id),
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        ''')
        
        # Criar usuário admin padrão
        password_hash = hashlib.sha256('admin123'.encode()).hexdigest()
        try:
            cursor.execute('''
                INSERT INTO users (username, password, name, role)
                VALUES (?, ?, ?, ?)
            ''', ('admin', password_hash, 'Administrador', 'admin'))
        except sqlite3.IntegrityError:
            pass  # Usuário já existe
        
        conn.commit()
        conn.close()
    
    # ===== MÉTODOS DE USUÁRIOS =====
    
    def authenticate_user(self, username, password):
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT id, username, name, role, active
            FROM users
            WHERE username = ? AND password = ? AND active = 1
        ''', (username, password_hash))
        
        user = cursor.fetchone()
        conn.close()
        
        if user:
            return dict(user)
        return None
    
    def create_user(self, username, password, name, role):
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT INTO users (username, password, name, role)
                VALUES (?, ?, ?, ?)
            ''', (username, password_hash, name, role))
            conn.commit()
            user_id = cursor.lastrowid
            conn.close()
            return user_id
        except sqlite3.IntegrityError:
            conn.close()
            return None
    
    def get_all_users(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT id, username, name, role, active FROM users')
        users = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return users
    
    # ===== MÉTODOS DE LEADS =====
    
    def create_or_get_lead(self, phone, name=None):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Verificar se lead já existe
        cursor.execute('SELECT * FROM leads WHERE phone = ?', (phone,))
        lead = cursor.fetchone()
        
        if lead:
            conn.close()
            return dict(lead)
        
        # Criar novo lead
        cursor.execute('''
            INSERT INTO leads (phone, name, status)
            VALUES (?, ?, 'novo')
        ''', (phone, name))
        conn.commit()
        lead_id = cursor.lastrowid
        
        cursor.execute('SELECT * FROM leads WHERE id = ?', (lead_id,))
        new_lead = dict(cursor.fetchone())
        conn.close()
        return new_lead
    
    def get_leads_by_status(self, status):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT l.*, u.name as vendedor_name
            FROM leads l
            LEFT JOIN users u ON l.assigned_to = u.id
            WHERE l.status = ?
            ORDER BY l.updated_at DESC
        ''', (status,))
        leads = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return leads
    
    def get_leads_by_vendedor(self, vendedor_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT * FROM leads
            WHERE assigned_to = ?
            ORDER BY updated_at DESC
        ''', (vendedor_id,))
        leads = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return leads
    
    def assign_lead(self, lead_id, vendedor_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE leads
            SET assigned_to = ?, status = 'em_atendimento', updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (vendedor_id, lead_id))
        conn.commit()
        conn.close()
    
    def update_lead_status(self, lead_id, status):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE leads
            SET status = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (status, lead_id))
        conn.commit()
        conn.close()
    
    def get_lead_by_phone(self, phone):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM leads WHERE phone = ?', (phone,))
        lead = cursor.fetchone()
        conn.close()
        return dict(lead) if lead else None
    
    def get_all_leads(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT l.*, u.name as vendedor_name
            FROM leads l
            LEFT JOIN users u ON l.assigned_to = u.id
            ORDER BY l.updated_at DESC
        ''')
        leads = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return leads
    
    # ===== MÉTODOS DE MENSAGENS =====
    
    def save_message(self, lead_id, sender_type, content, sender_id=None, message_type='text'):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO messages (lead_id, sender_type, sender_id, content, message_type)
            VALUES (?, ?, ?, ?, ?)
        ''', (lead_id, sender_type, sender_id, content, message_type))
        conn.commit()
        message_id = cursor.lastrowid
        
        # Atualizar timestamp do lead
        cursor.execute('''
            UPDATE leads SET updated_at = CURRENT_TIMESTAMP WHERE id = ?
        ''', (lead_id,))
        conn.commit()
        conn.close()
        return message_id
    
    def get_messages_by_lead(self, lead_id, limit=100):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT m.*, u.name as sender_name
            FROM messages m
            LEFT JOIN users u ON m.sender_id = u.id
            WHERE m.lead_id = ?
            ORDER BY m.timestamp DESC
            LIMIT ?
        ''', (lead_id, limit))
        messages = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return list(reversed(messages))  # Mais antigas primeiro
    
    # ===== MÉTODOS DE NOTAS INTERNAS =====
    
    def add_internal_note(self, lead_id, user_id, note):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO internal_notes (lead_id, user_id, note)
            VALUES (?, ?, ?)
        ''', (lead_id, user_id, note))
        conn.commit()
        conn.close()
    
    def get_internal_notes(self, lead_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT n.*, u.name as user_name
            FROM internal_notes n
            JOIN users u ON n.user_id = u.id
            WHERE n.lead_id = ?
            ORDER BY n.created_at DESC
        ''', (lead_id,))
        notes = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return notes
    
    # ===== MÉTODOS DE GESTÃO DE USUÁRIOS =====
    
    def get_user_by_id(self, user_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT id, username, name, role, active FROM users WHERE id = ?', (user_id,))
        user = cursor.fetchone()
        conn.close()
        return dict(user) if user else None
    
    def update_user(self, user_id, name, role, active):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE users SET name = ?, role = ?, active = ? WHERE id = ?
        ''', (name, role, active, user_id))
        conn.commit()
        conn.close()
    
    def change_password(self, user_id, new_password):
        password_hash = hashlib.sha256(new_password.encode()).hexdigest()
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('UPDATE users SET password = ? WHERE id = ?', (password_hash, user_id))
        conn.commit()
        conn.close()
    
    def delete_user(self, user_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('UPDATE users SET active = 0 WHERE id = ?', (user_id,))
        conn.commit()
        conn.close()
    
    # ===== AUDIT LOG =====
    
    def log_action(self, user_id, action, entity_type, entity_id, details=None):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Criar tabela se não existir
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS audit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                action TEXT NOT NULL,
                entity_type TEXT NOT NULL,
                entity_id INTEGER,
                details TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        ''')
        
        cursor.execute('''
            INSERT INTO audit_log (user_id, action, entity_type, entity_id, details)
            VALUES (?, ?, ?, ?, ?)
        ''', (user_id, action, entity_type, entity_id, details))
        conn.commit()
        conn.close()
    
    def get_audit_log(self, limit=100, entity_type=None, entity_id=None):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        query = '''
            SELECT a.*, u.name as user_name
            FROM audit_log a
            JOIN users u ON a.user_id = u.id
        '''
        params = []
        
        if entity_type and entity_id:
            query += ' WHERE a.entity_type = ? AND a.entity_id = ?'
            params = [entity_type, entity_id]
        elif entity_type:
            query += ' WHERE a.entity_type = ?'
            params = [entity_type]
        
        query += ' ORDER BY a.created_at DESC LIMIT ?'
        params.append(limit)
        
        cursor.execute(query, params)
        logs = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return logs
