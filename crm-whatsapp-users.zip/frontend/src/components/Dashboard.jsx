import { useState, useEffect } from 'react';
import { MessageCircle, Users, Send, LogOut, Settings } from 'lucide-react';
import api from '../api';
import io from 'socket.io-client';
import UserManagement from './UserManagement';

export default function Dashboard({ user, onLogout }) {
  const [activeTab, setActiveTab] = useState('meus-leads');
  const [showSettings, setShowSettings] = useState(false); // 'meus-leads' ou 'fila'
  const [leads, setLeads] = useState([]);
  const [queueLeads, setQueueLeads] = useState([]);
  const [selectedLead, setSelectedLead] = useState(null);
  const [messages, setMessages] = useState([]);
  const [messageInput, setMessageInput] = useState('');
  const [socket, setSocket] = useState(null);

  // Conectar Socket.io
  useEffect(() => {
    const newSocket = io('http://localhost:5000');
    setSocket(newSocket);

    // Eventos do Socket.io
    newSocket.on('connect', () => {
      console.log('✅ Conectado ao Socket.io');
    });

    newSocket.on('new_message', (data) => {
      console.log('📨 Nova mensagem recebida:', data);
      
      // Se for do lead selecionado, adicionar às mensagens
      if (selectedLead && data.lead_id === selectedLead.id) {
        setMessages((prev) => [...prev, {
          content: data.content,
          sender_type: data.sender_type,
          timestamp: data.timestamp,
        }]);
      }
      
      // Atualizar lista de leads
      loadLeads();
      loadQueue();
    });

    newSocket.on('message_sent', (data) => {
      console.log('✅ Mensagem enviada confirmada:', data);
    });

    newSocket.on('lead_assigned', (data) => {
      console.log('👤 Lead atribuído:', data);
      loadLeads();
      loadQueue();
    });

    return () => newSocket.close();
  }, []);

  // Carregar leads do usuário
  const loadLeads = async () => {
    try {
      const data = await api.getLeads();
      setLeads(data);
    } catch (error) {
      console.error('Erro ao carregar leads:', error);
    }
  };

  // Carregar fila de leads
  const loadQueue = async () => {
    try {
      const data = await api.getLeadsQueue();
      setQueueLeads(data);
    } catch (error) {
      console.error('Erro ao carregar fila:', error);
    }
  };

  // Carregar mensagens do lead
  const loadMessages = async (leadId) => {
    try {
      const data = await api.getMessages(leadId);
      setMessages(data);
    } catch (error) {
      console.error('Erro ao carregar mensagens:', error);
    }
  };

  useEffect(() => {
    loadLeads();
    loadQueue();
    
    // Atualizar a cada 10 segundos
    const interval = setInterval(() => {
      loadLeads();
      loadQueue();
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  // Selecionar lead
  const handleSelectLead = (lead) => {
    setSelectedLead(lead);
    loadMessages(lead.id);
  };

  // Pegar lead da fila
  const handleAssignLead = async (leadId) => {
    try {
      await api.assignLead(leadId);
      loadLeads();
      loadQueue();
      
      // Selecionar automaticamente o lead
      const lead = queueLeads.find(l => l.id === leadId);
      if (lead) {
        handleSelectLead({ ...lead, assigned_to: user.id });
      }
    } catch (error) {
      console.error('Erro ao pegar lead:', error);
    }
  };

  // Enviar mensagem
  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!messageInput.trim() || !selectedLead) return;

    try {
      await api.sendMessage(selectedLead.id, messageInput);
      
      // Adicionar mensagem localmente
      setMessages((prev) => [...prev, {
        content: messageInput,
        sender_type: 'vendedor',
        sender_name: user.name,
        timestamp: new Date().toISOString(),
      }]);
      
      setMessageInput('');
    } catch (error) {
      console.error('Erro ao enviar mensagem:', error);
    }
  };

  // Formatar timestamp
  const formatTime = (timestamp) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  };

  // Renderizar lista de leads
  const renderLeadsList = (leadsList, showAssignButton = false) => {
    if (leadsList.length === 0) {
      return (
        <div style={{ padding: '40px 20px', textAlign: 'center', color: '#8696a0' }}>
          <p>Nenhum lead aqui ainda</p>
        </div>
      );
    }

    return leadsList.map((lead) => (
      <div
        key={lead.id}
        className={`lead-item ${selectedLead?.id === lead.id ? 'active' : ''}`}
        onClick={() => !showAssignButton && handleSelectLead(lead)}
      >
        <div className="lead-item-header">
          <span className="lead-name">{lead.name || lead.phone}</span>
          <span className="lead-time">{formatTime(lead.updated_at)}</span>
        </div>
        <div className="lead-last-message">
          {lead.phone}
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '8px' }}>
          <span className={`lead-status status-${lead.status}`}>
            {lead.status.replace('_', ' ')}
          </span>
          {showAssignButton && (
            <button 
              className="btn btn-primary"
              style={{ padding: '6px 12px', fontSize: '12px' }}
              onClick={(e) => {
                e.stopPropagation();
                handleAssignLead(lead.id);
              }}
            >
              Pegar Lead
            </button>
          )}
        </div>
      </div>
    ));
  };

  return (
    <div className="app-container">
      {showSettings ? (
        <div style={{ width: '100%', background: '#111b21' }}>
          <div style={{ padding: '20px', background: '#202c33', borderBottom: '1px solid #2a3942', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h2>Configurações</h2>
            <button className="btn btn-secondary" onClick={() => setShowSettings(false)}>Voltar</button>
          </div>
          <UserManagement currentUser={user} />
        </div>
      ) : (
        <>
          {/* SIDEBAR */}
          <div className="sidebar">
        <div className="sidebar-header">
          <h2>CRM WhatsApp</h2>
          <div className="user-info">
            <span>{user.name}</span>
            <span className="role-badge">{user.role}</span>
          </div>
          <div style={{ display: 'flex', gap: '5px', marginTop: '10px' }}>
            {(user.role === 'admin' || user.role === 'gestor') && (
              <button className="btn btn-secondary" onClick={() => setShowSettings(true)} style={{ flex: 1 }}>
                <Settings size={16} /> Config
              </button>
            )}
            <button className="logout-button" onClick={onLogout} style={{ flex: 1 }}>
              <LogOut size={16} /> Sair
            </button>
          </div>
        </div>

        <div className="sidebar-tabs">
          <button
            className={`tab ${activeTab === 'meus-leads' ? 'active' : ''}`}
            onClick={() => setActiveTab('meus-leads')}
          >
            <MessageCircle size={18} style={{ marginRight: '5px', verticalAlign: 'middle' }} />
            Meus Leads ({leads.length})
          </button>
          <button
            className={`tab ${activeTab === 'fila' ? 'active' : ''}`}
            onClick={() => setActiveTab('fila')}
          >
            <Users size={18} style={{ marginRight: '5px', verticalAlign: 'middle' }} />
            Fila ({queueLeads.length})
          </button>
        </div>

        <div className="leads-list">
          {activeTab === 'meus-leads' && renderLeadsList(leads)}
          {activeTab === 'fila' && renderLeadsList(queueLeads, true)}
        </div>
      </div>

      {/* CHAT AREA */}
      <div className="chat-container">
        {selectedLead ? (
          <>
            <div className="chat-header">
              <div className="chat-header-info">
                <h3>{selectedLead.name || selectedLead.phone}</h3>
                <p>{selectedLead.phone}</p>
              </div>
              <div className="chat-actions">
                <span className={`lead-status status-${selectedLead.status}`}>
                  {selectedLead.status.replace('_', ' ')}
                </span>
              </div>
            </div>

            <div className="chat-messages">
              {messages.map((msg, index) => (
                <div key={index} className={`message from-${msg.sender_type}`}>
                  <div className="message-bubble">
                    {msg.sender_type === 'vendedor' && (
                      <div className="message-sender">{msg.sender_name || 'Você'}</div>
                    )}
                    <div className="message-content">{msg.content}</div>
                    <div className="message-time">{formatTime(msg.timestamp)}</div>
                  </div>
                </div>
              ))}
            </div>

            <div className="chat-input-container">
              <form onSubmit={handleSendMessage} className="chat-input-wrapper">
                <input
                  type="text"
                  className="chat-input"
                  placeholder="Digite sua mensagem..."
                  value={messageInput}
                  onChange={(e) => setMessageInput(e.target.value)}
                />
                <button type="submit" className="send-button">
                  <Send size={20} />
                </button>
              </form>
            </div>
          </>
        ) : (
          <div className="empty-state">
            <MessageCircle size={80} />
            <h3>Selecione um lead para começar</h3>
            <p>Escolha um lead da lista ou pegue um da fila</p>
          </div>
        )}
      </div>
        </>
      )}
    </div>
  );
}
